# MT5599 Supplementary Code 

# Import required libraries 
library(pheatmap)
library(dtwclust)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(factoextra)
library(rlist)
library(readxl)
library(lomb)

hes5data = read.csv(file= "2022_07_05_p2p4_HES5.csv",header = F)
ngn2data = read.csv(file= "2022_07_05_p2p4_NGN2.csv",header = F)

timehes5data = hes5data$V1 
timengn2data  = ngn2data$V1
timehes5data == timengn2data # identical

tt = timehes5data # time for both genes (it's the same for both)

# Create new dataset with only the cells with differences between hes5 and ngn2 timeseries
ddhes5 = hes5data[,2:ncol(hes5data)] # hes5 data  
ddngn2 = ngn2data[,2:ncol(ngn2data)]

# Add column with time variable to datasets
library(tibble)
ddhes5tt = add_column(ddhes5, tt, .before = 1)
ddngn2tt = add_column(ddngn2, tt, .before = 1)

########### Remove Background Noise ##############

# Background values of time series
hes5_bg <- c(245, 211, 240, 239)
ngn2_bg <- c(164, 200, 197, 214, 249, 275)

# Find the mean background value
mean_hes5_bg <- mean(hes5_bg) # 233.75
mean_ngn2_bg <- mean(ngn2_bg) # 216.5

# Subtracting will result in negative intensities?
min(ddhes5tt[,2:length(ddhes5tt)], na.rm = TRUE) # 171.607
min(ddngn2tt[,2:length(ddngn2tt)], na.rm = TRUE) # 96.3293

# Subtract mean background value from time series
ddhes5tt[,2:length(ddhes5tt)] <- ddhes5tt[,2:length(ddhes5tt)] - mean_hes5_bg
ddngn2tt[,2:length(ddngn2tt)] <- ddngn2tt[,2:length(ddngn2tt)] - mean_ngn2_bg

# Replace any negative intensities with 0
ddhes5tt[ddhes5tt < 0] <- 0
ddngn2tt[ddngn2tt < 0] <- 0

########### Remove cells with too few data points ############

# Function to find the length of the time series for each cell
lengths = rep(NA, length(ddhes5))
for (i in 1:length(ddhes5)){
  l = length(na.omit(ddhes5[,i]))
  lengths[i] = l
}

lengths = data.frame(lengths)

library(ggplot2)
ggplot(data = lengths, aes(x = lengths, y = after_stat(density))) +
  geom_histogram(bins = 10) + geom_density(color = "red", linewidth = 1) + 
  labs(x = "Length", y = "Density")

library(dplyr)
# Divide the data into 10 bins
bins = lengths %>%
  mutate(bins = cut_interval(lengths, n = 10))
# Number each bin
bins = bins %>%
  mutate(bin_indices = group_indices(., bins))
# Find the index of each time series in the 2 bins with the least data points
rm_indices = which(bins$bin_indices %in% c(1, 2, 3))

# Create new data sets with only the time series with sufficient data points
ddhes5tt = ddhes5tt[-(rm_indices+1)]
ddngn2tt = ddngn2tt[-(rm_indices+1)]

########## Plot intensities of HES5 and NGN2 for every cell ########

pdf("timeseries_hrs.pdf") 
par(mfrow = c(3, 3), mar=c(4.5, 4.5, 3, 3))
for (i in 2:(length(ddhes5tt))){
  plot(ddhes5tt[,1] / 3600, ddhes5tt[,i], type = "l", col = 1, ylim = c(0, 3500), 
       main = colnames(ddhes5tt)[i], xlab = "Time (hrs)", ylab = "HES5 Intensity")
  lines(ddngn2tt[,1] / 3600, ddngn2tt[,i], type = "l", col = 2)
  axis(4)
  mtext("NGN2 Intensity", side = 4, line = 2, col = 2, cex = 0.7)
}
dev.off()

########### Cross-correlation against lag for every cell with WN CIs ############

pdf("cc_WN.pdf") 
par(mfrow = c(3, 3), mar=c(4.5, 4.5, 3, 3))
for (i in 2:(length(ddhes5tt))){
  c <- ccf(ddhes5tt[,i], ddngn2tt[,i], na.action = na.omit, lag.max = sum(!is.na(ddhes5tt[,i])), 
           xlim = c(-120,120), ylim = c(-1,1), plot = FALSE)
  plot(c, xlim = c(-120,120), ylim = c(-1,1), main = colnames(ddhes5tt)[i],
       xlab = "Time (hrs)", ylab = "Cross-Correlation", xaxt="n")
  axis(1, at= c(-100, -50, 0, 50, 100), label = c(-20, -10, 0, 10, 20), las=1)
}
dev.off()

########### Cross-correlation against lag for every cell with bootstrap CIs ############

# 63rd, 66th out of the 75 cells used in the analysis produces error: 'ar' part of model is not stationary
ddhes5tt <- ddhes5tt[-c(63, 66)]
ddngn2tt <- ddngn2tt[-c(63, 66)]

# Manually create cc plots (automatic plots from ccf_boot messy)
d_all <- list()
p_all <- list()
for (i in 2:length(ddhes5tt)){
  # Compute the correlation values at every lag as well as the CI
  cc_boot <- ccf_boot(na.omit(ddhes5tt[,i]), na.omit(ddngn2tt[,i]), 
                      lag.max = sum(!is.na(ddhes5tt[,i])), plot = "none")
  # Store these values in a dataframe 
  data <- data.frame(lag = cc_boot$Lag,
                     cc = cc_boot$r_P,
                     upper_ci = cc_boot$upper_P,
                     lower_ci = cc_boot$lower_P)
  # Determine for each lag if the correlation value is significant
  data$sig <- ifelse(data$cc < data$upper_ci & data$cc > data$lower_ci, "not", "sig")
  # Store the dataframe for this cell in d_all
  d_all[[i-1]] <- data
  
  # Create a plot of the correlation values for each lag and the confidence intervals 
  p <- ggplot(data, aes(x = lag)) +
    # Colour the points at each correlation value based on whether it is significant 
    geom_point(aes(y = cc, color = sig), size = 0.8) + scale_color_manual(values = c("not" = "grey", "sig" = "red")) + 
    geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci), fill = "lightblue", alpha = 0.5) +
    geom_segment(aes(x = lag, y = 0, xend = lag, yend = cc), color = "black") +
    labs(x = "Lag",
         y = "Pearson Correlation") +
    ggtitle(colnames(ddhes5tt)[i]) +
    theme_minimal() + 
    scale_x_continuous(name = "Time(hrs)", limits = c(-120, 120), 
                       breaks = c(-100, -50, 0, 50, 100), labels = c("-20", "-10", "0", "10", "20")) + 
    ylim(-1,1) 
  # Store the plot in p_all
  p_all[[i-1]] <- p
}

pdf("cc_boot.pdf")
for (i in seq(from=1, to=72, by=4))
  grid.arrange(p_all[[i]], p_all[[i+1]], 
               p_all[[i+2]], p_all[[i+3]], ncol = 2, nrow = 2)
dev.off()

# Find the lags at which a cc value is significant 
sig_lags <- c()
for (i in 1:length(d_all)){
  df <- d_all[[i]]
  sig_lag <- d_all[[i]]$lag[which(d_all[[i]]$sig == "sig")]
  sig_lags <- c(sig_lag, sig_lags)
}

sig_lags_df <- data.frame("sig_lags" = sig_lags)

sig_corrs <- c()
for (i in 1:length(d_all)){
  df <- d_all[[i]]
  sig_corr <- d_all[[i]]$cc[which(d_all[[i]]$sig == "sig")]
  sig_corrs <- c(sig_corr, sig_corrs)
}

sig_corrs_df <- data.frame("sig_corrs" = sig_corrs)

pdf("sig_cc_summary.pdf")
# Plot a histogram of the distribution of lags at which significant cc values occur
ggplot(data = sig_lags_df, aes(x = sig_lags, y = after_stat(density))) +
  geom_histogram() + geom_density(color = "red", linewidth = 1) +
  labs(y = "Density", 
       title = "Histogram of the time lag at which a significant correlation occurs") + 
  scale_x_continuous(name = "Time(hrs)", limits = c(-120, 120), 
                     breaks = c(-100, -50, 0, 50, 100), labels = c("-20", "-10", "0", "10", "20"))


# Plot a histogram of the distribution of significant cc values
ggplot(data = sig_corrs_df, aes(x = sig_corrs, y = after_stat(density))) +
  geom_histogram() + geom_density(color = "red", linewidth = 1) +
  labs(y = "Density", x = "Cross-correlation value",
       title = "Histogram of all significant correlation values across all cells") 
dev.off()

######## Function to compute cross-correlation between two time series from scratch ##########

# Cross-correlation function from scratch 
cross_correlation <- function(series1, series2, lag.max = NULL) {
  
  # Check if input series are of equal length
  if (length(series1) != length(series2)) {
    stop("Input time series must be of equal length.")
  }
  
  n <- length(series1)
  
  # If lag.max is not provided, set it to the length of the series
  if (is.null(lag.max)) {
    lag.max <- length(series1)
  }
  
  # Initialize cross-correlation vector
  cross_corr <- numeric(2 * lag.max + 1)
  
  # Calculate cross-correlation for each lag
  for (lag in -(lag.max-1):(lag.max-1)) {
    
    if (lag < 0){
      
      # Calculate mean of each series
      mean_series1 <- mean(series1[1:(n - abs(lag))])
      mean_series2 <- mean(series2[(1 + abs(lag)):n])
      
      # Calculate numerator for the current lag
      num <- cov(series1[1:(n - abs(lag))], series2[(1 + abs(lag)):n])
      
      # Normalize by the product of standard deviations
      cross_corr[lag + lag.max + 1] <- num / (sd(series1[1:(n - abs(lag))]) * sd(series2[(1 + abs(lag)):n]))
      
    }
    
    if (lag >= 0){
      # Calculate mean of each series
      mean_series1 <- mean(series1[(1+lag):n])
      mean_series2 <- mean(series2[1:(n-lag)])
      
      # Calculate numerator for the current lag
      num <- cov(series1[(1+lag):n], series2[1:(n-lag)])
      
      # Normalize by the product of standard deviations
      cross_corr[lag + lag.max + 1] <- num / (sd(series1[(1+lag):n]) * sd(series2[1:(n-lag)]))
    }
    
    lag <- seq(-lag.max, lag.max, 1)
    
    cc <- list(acf = cross_corr, lag = lag)
  }
  
  # Return the cross-correlation vector
  return(cc)
}


ccf_own_boot <- function(x,
                         y,
                         lag.max = NULL,
                         plot = c("Pearson", "Spearman", "none"),
                         level = 0.95,
                         B = 1000,
                         smooth = FALSE,
                         cl = 1L,
                         ...)
{
  ### Perform various checks
  namex <- deparse(substitute(x))[1L]
  namey <- deparse(substitute(y))[1L]
  if (is.matrix(x) || is.matrix(y)) {
    stop("x and y should be univariate time series only.")
  }
  if (any(is.na(x)) || any(is.na(y))) {
    stop("data should not contain missing values.")
  }
  nx <- length(x)
  ny <- length(y)
  B <- as.integer(B)
  if (B <= 0) {
    stop("number of bootstrap resamples B must be positive.")
  }
  plt <- match.arg(plot)
  bootparallel <- FALSE
  if (is.list(cl)) { #some other cluster supplied; use it but do not stop it
    bootparallel <- TRUE
    clStop <- FALSE
  } else {
    if (is.null(cl)) {
      cores <- parallel::detectCores()
    } else {
      cores <- cl
    }
    if (cores > 1) { #specified or detected cores>1; start a cluster and later stop it
      bootparallel <- TRUE
      cl <- parallel::makeCluster(cores)
      clStop <- TRUE
    }
  }
  ### Function
  xrank <- rank(x)
  yrank <- rank(y)
  attributes(xrank) <- attributes(x)
  attributes(yrank) <- attributes(y)
  tmp <- cross_correlation(x, y, lag.max = lag.max)
  lags <- tmp$lag
  rP <- tmp$acf
  rS <- cross_correlation(xrank, yrank, lag.max = lag.max)$acf
  phetax <- ARest(x, ...)
  phetay <- ARest(y, ...)
  if (length(phetax) > 0) {
    names(phetax) <- paste0(rep("phi_", length(phetax)), c(1:length(phetax)))
    tmp <- stats::filter(x, phetax, sides = 1)
    Zx <- x[(length(phetax) + 1):nx] - tmp[length(phetax):(nx - 1)]
  } else {
    Zx <- x
  }
  Zx <- Zx - mean(Zx)
  if (length(phetay) > 0) {
    names(phetay) <- paste0(rep("phi_", length(phetay)), c(1:length(phetay)))
    tmp <- stats::filter(y, phetay, sides = 1)
    Zy <- y[(length(phetay) + 1):ny] - tmp[length(phetay):(ny - 1)]
  } else {
    Zy <- y
  }
  Zy <- Zy - mean(Zy)
  ### Bootstrap
  if (bootparallel) {
    CCFs <- parallel::parSapply(cl, 1:B, function(b) {
      xboot <- arima.sim(list(order = c(length(phetax), 0, 0), ar = phetax), n = nx,
                         innov = sample(Zx, size = nx, replace = TRUE))
      yboot <- arima.sim(list(order = c(length(phetay), 0, 0), ar = phetay), n = ny,
                         innov = sample(Zy, size = ny, replace = TRUE))
      xrankboot <- rank(xboot)
      yrankboot <- rank(yboot)
      attributes(xboot) <- attributes(xrankboot) <- attributes(x)
      attributes(yboot) <- attributes(yrankboot) <- attributes(y)
      rPboot <- cross_correlation(xboot, yboot, lag.max = lag.max)$acf
      rSboot <- cross_correlation(xrankboot, yrankboot, lag.max = lag.max)$acf
      cbind(rPboot, rSboot)
    }, simplify = "array")
    if (clStop) {
      parallel::stopCluster(cl)
    }
  } else {
    CCFs <- sapply(1:B, function(b) {
      xboot <- arima.sim(list(order = c(length(phetax), 0, 0), ar = phetax), n = nx,
                         innov = sample(Zx, size = nx, replace = TRUE))
      yboot <- arima.sim(list(order = c(length(phetay), 0, 0), ar = phetay), n = ny,
                         innov = sample(Zy, size = ny, replace = TRUE))
      xrankboot <- rank(xboot)
      yrankboot <- rank(yboot)
      attributes(xboot) <- attributes(xrankboot) <- attributes(x)
      attributes(yboot) <- attributes(yrankboot) <- attributes(y)
      rPboot <- cross_correlation(xboot, yboot, lag.max = lag.max)$acf
      rSboot <- cross_correlation(xrankboot, yrankboot, lag.max = lag.max)$acf
      cbind(rPboot, rSboot)
    }, simplify = "array")
  } # end sequential bootstrap
  #CCFs has dimensions of nlags * 2 (Pearson and Spearman) * B
  ### Confidence regions
  alpha <- 1 - level
  # Percentile
  # crP <- apply(CCFs[,1,], 1, quantile, probs = c(alpha/2, 1 - alpha / 2))
  # crS <- apply(CCFs[,2,], 1, quantile, probs = c(alpha/2, 1 - alpha / 2))
  # Normal
  crP <- apply(CCFs[,1,], 1, function(x) qnorm(1 - alpha / 2, sd = sd(x)))
  if (smooth) {
    crP <- loess(crP ~ lags, span = 0.25)$fitted
  }
  crP <- rbind(-crP, crP)
  crS <- apply(CCFs[,2,], 1, function(x) qnorm(1 - alpha / 2, sd = sd(x)))
  if (smooth) {
    crS <- loess(crS ~ lags, span = 0.25)$fitted
  }
  crS <- rbind(-crS, crS)
  ### p-values
  # pP <- sapply(1:dim(CCFs)[1L], function(i) mean(abs(CCFs[i,1,]) > abs(rP[i])))
  # pS <- sapply(1:dim(CCFs)[1L], function(i) mean(abs(CCFs[i,2,]) > abs(rS[i])))
  RESULT <- data.frame(Lag = lags,
                       r_P = rP, #p_P = pP,
                       lower_P = crP[1,], upper_P = crP[2,], #Pearson
                       r_S = rS, #p_S = pS,
                       lower_S = crS[1,], upper_S = crS[2,]) #Spearman
  ### Plotting
  if (plt == "Pearson") {
    TMP <- RESULT[,grepl("_P", names(RESULT))]
  }
  if (plt == "Spearman") {
    TMP <- RESULT[,grepl("_S", names(RESULT))]
  }
  if (plt == "Pearson" || plt == "Spearman") {
    matplot(lags, TMP, type = "n",
            xlab = "Lag", ylab = "CCF",
            main = paste0(plt, " correlation of ", namex, "(t + Lag)", " and ", namey, "(t)\n",
                          "with ", level*100, "% bootstrap confidence region"),
            las = 1)
    grid(nx = 2, ny = NULL, lty = 1)
    polygon(x = c(lags, rev(lags)),
            y = c(TMP[,2], rev(TMP[,3])),
            col =  adjustcolor("deepskyblue", alpha.f = 0.80),
            border = NA)
    lines(lags, TMP[,1], type = "h")
    isoutside <- (TMP[,1] < TMP[,2]) | (TMP[,3] < TMP[,1])
    points(lags, TMP[,1], pch = c(1, 16)[1 + isoutside])
    return(invisible(RESULT))
  } else {
    return(RESULT)
  }
}


cc <- ccf_boot(na.omit(ddhes5tt[,20]), na.omit(ddngn2tt[,20]), 
               lag.max = sum(!is.na(ddhes5tt[,20])))
# Store these values in a dataframe 
data <- data.frame(lag = cc$Lag,
                   cc = cc$r_P,
                   upper_ci = cc$upper_P,
                   lower_ci = cc$lower_P)
# Determine for each lag if the correlation value is significant
data$sig <- ifelse(data$cc < data$upper_ci & data$cc > data$lower_ci, "not", "sig")

# Create a plot of the correlation values for each lag and the confidence intervals 
ggplot(data, aes(x = lag)) +
  geom_point(aes(y = cc, color = sig), size = 0.8) + scale_color_manual(values = c("not" = "darkgray", "sig" = "red")) + 
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci), fill = "lightblue", alpha = 0.5) +
  geom_segment(aes(x = lag, y = 0, xend = lag, yend = cc), color = "black", linewidth = 0.3) +
  labs(x = "Lag",
       y = "Pearson Correlation") +
  ggtitle("Cross-Correlation of cell", colnames(ddhes5tt)[20]) +
  theme_minimal() + 
  scale_x_continuous(name = "Time(hrs)", limits = c(-120, 120), 
                     breaks = c(-100, -50, 0, 50, 100), labels = c("-20", "-10", "0", "10", "20")) + 
  ylim(-1,1) 


# Manually create cc plots
d_own_all <- list()
p_own_all <- list()
for (i in 2:length(ddhes5tt)){
  # Compute the correlation values at every lag as well as the CI
  cc_own_boot <- ccf_own_boot(na.omit(ddhes5tt[,i]), na.omit(ddngn2tt[,i]), 
                      lag.max = sum(!is.na(ddhes5tt[,i])), plot = "none")
  # Store these values in a dataframe 
  data <- data.frame(lag = cc_own_boot$Lag,
                     cc = cc_own_boot$r_P,
                     upper_ci = cc_own_boot$upper_P,
                     lower_ci = cc_own_boot$lower_P)
  # Determine for each lag if the correlation value is significant
  data$sig <- ifelse(data$cc < data$upper_ci & data$cc > data$lower_ci, "not", "sig")
  # Store the dataframe for this cell in d_all
  d_own_all[[i-1]] <- data
  
  # Create a plot of the correlation values for each lag and the confidence intervals 
  p_own <- ggplot(data, aes(x = lag)) +
    # Colour the points at each correlation value based on whether it is significant 
    geom_point(aes(y = cc, color = sig), size = 0.8) + scale_color_manual(values = c("not" = "grey", "sig" = "red")) + 
    geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci), fill = "lightblue", alpha = 0.5) +
    geom_segment(aes(x = lag, y = 0, xend = lag, yend = cc), color = "black") +
    labs(x = "Lag",
         y = "Pearson Correlation") +
    ggtitle(colnames(ddhes5tt)[i]) +
    theme_minimal() + 
    scale_x_continuous(name = "Time(hrs)", limits = c(-120, 120), 
                       breaks = c(-100, -50, 0, 50, 100), labels = c("-20", "-10", "0", "10", "20")) + 
    ylim(-1,1) 
  # Store the plot in p_all
  p_own_all[[i-1]] <- p_own
}

pdf("cc_own_boot_all.pdf")
for (i in seq(from=1, to=72, by=4))
  grid.arrange(p_own_all[[i]], p_own_all[[i+1]], 
               p_own_all[[i+2]], p_own_all[[i+3]], ncol = 2, nrow = 2)
dev.off()

########## Clustering using Euclidean distance ############

# Create a dataframe with the cross-correlation values for each cell 
length <- c()
for (i in 1:length(d_all)){
  length <- c(length, length(d_all[[i]]$lag))
}

len_df <- max(length)

columns = colnames(ddhes5tt)
cc_df = data.frame(matrix(NA, nrow = len_df, ncol = length(columns))) 
colnames(cc_df) = columns
names(cc_df)[1] <- "lag"

cc_df$lag <- d_all[[which(length == len_df)]]$lag

for (i in 1:length(d_all)){
  min_lag <- min(d_all[[i]]$lag)
  ind_start <- which(cc_df$lag == min_lag)
  cc_df[,i+1][ind_start:(ind_start+length(d_all[[i]]$lag)-1)] <- d_all[[i]]$cc
}

# Set all time series to be between -50 and 50 lags
cc_df_short <- cc_df %>% filter(lag > -50 & lag < 50)
# Pad with zeros
cc_df_short <- cc_df_short %>% replace(is.na(.), 0)

cc_list_short <- list()
for (i in 2:length(cc_df_short)){
  cc_list_short[[i]] <- cc_df_short[i]
}
cc_list_short <- cc_list_short[-1]

cc_matrix_short <- as.matrix(cc_df_short[,2:length(cc_df_short)])

# Calculate the euclidean distance matrix
euc_distances <- dist(t(cc_matrix_short), method = "euclidean", upper = TRUE, diag = TRUE)
# Perform hierarchical clustering with complete linkage 
clust_hier <- hclust(euc_distances, method = "complete")
# Plot the dendrogram
plot(clust_hier)

# Set labels along y axis to be in terms of time (hrs) rather than lag
reordered_cc <- cc_matrix_short[,unlist(clust_hier$order)]
dendrogram <- as.dendrogram(clust_hier)
tt_hrs_pos <- ddhes5tt[1:50,1] / 3600
tt_hrs_neg <- rev(-1 * tt_hrs_pos)
all_tt_hrs <- c(tt_hrs_neg[-length(tt_hrs_neg)], tt_hrs_pos)
desired_row_labels <- c(-40, -20, 0, 20, 40)
row_labels <- rep("", length(cc_df_short$lag))
desired_indices <- which(cc_df_short$lag %in% desired_row_labels)
row_labels[desired_indices] <- as.character(round(all_tt_hrs[desired_indices],1))

pdf("clustering_output.pdf", paper = "a4r")
# Produce heatmap 
pheatmap(
  cc_matrix_short,
  clustering_distance_cols = euc_distances,
  cluster_rows = FALSE,
  clustering_method = "complete", 
  col_dendrogram = dendrogram,
  fontsize_row=8, fontsize = 8,
  labels_row = row_labels, xlab = "Cell", cutree_cols=6, 
  main = "Clustering of the cross-correlation values of each cell (complete)"
)

# Hierarchical clustering using Euclidean distances and complete linkage for more visuals: 6 clusters 
clust_hier <- tsclust(t(cc_matrix_short), type="hierarchical", k=6L, distance="L2", trace = FALSE,
                      control = hierarchical_control(method = "complete"))

# Plot time series from a given cluster in one plot
plot(clust_hier, type = "series") + 
  xlab("Time (hrs)") + ylab("Cross-Correlation value") + 
  scale_x_continuous(breaks = c(0, 25, 50, 75, 100), labels = c(-10, -5, 0, 5, 10))

# Plot prototype obtained by applying shape extraction to clusters
plot(clust_hier, type = "centroids") + 
  xlab("Time (hrs)") + ylab("Cross-Correlation value") + 
  scale_x_continuous(breaks = c(0, 25, 50, 75, 100), labels = c(-10, -5, 0, 5, 10)) 

# Look at which cells assigned to which cluster
clusts <- clust_hier@cluster

# Function to create plots of the timeseries of HES5 and NGN2 intensities for a given cluster 
cluster_plot_HES5_NGN2 <- function(cc_df, clusters, hes5, ngn2, clust_no){
  # Obtain names of the cells in given cluster
  c1_cells <- colnames(cc_df[,2:length(cc_df)])[which(clusters == clust_no)]
  
  # Obtain a list of all HES5 intensity values at all times for each cell in given cluster
  c1_cells_df_HES5 <- hes5 %>% select(c1_cells)
  c1_HES5 <- as.vector(as.matrix(c1_cells_df_HES5))
  # Obtain a list of all HES5 intensity values at all times for each cell in given cluster
  c1_cells_df_NGN2 <- ngn2 %>% select(c1_cells)
  c1_NGN2 <- as.vector(as.matrix(c1_cells_df_NGN2))
  
  # Create a dataframe
  c1_df <- data.frame("HES5" = c1_HES5, "NGN2" = c1_NGN2, 
                      "Time" = rep(hes5[,1] / 3600, 
                                   "Cell" = length(c1_cells)), 
                      "Cell" = rep(c1_cells, each=length(ddhes5tt[,1])))
  
  # Create plots
  plot1 <- ggplot(c1_df, aes(x=Time, y=HES5, group=Cell, color=Cell)) +
    geom_line() + ggtitle("HES5: Cluster", clust_no)
  plot2 <- ggplot(c1_df, aes(x=Time, y=NGN2, group=Cell, color=Cell)) +
    geom_line() + ggtitle("NGN2: Cluster", clust_no)
  
  ggarrange(plot1, plot2, ncol = 2, nrow = 1, common.legend = TRUE, legend = "bottom")
}

# Create plots of the intensities time series of HES5 and NGN2 for cells in a given cluster
cluster_plot_HES5_NGN2(cc_df_short, clusts, ddhes5tt, ddngn2tt, 1)
cluster_plot_HES5_NGN2(cc_df_short, clusts, ddhes5tt, ddngn2tt, 2)
cluster_plot_HES5_NGN2(cc_df_short, clusts, ddhes5tt, ddngn2tt, 3)
cluster_plot_HES5_NGN2(cc_df_short, clusts, ddhes5tt, ddngn2tt, 4)
cluster_plot_HES5_NGN2(cc_df_short, clusts, ddhes5tt, ddngn2tt, 5)
cluster_plot_HES5_NGN2(cc_df_short, clusts, ddhes5tt, ddngn2tt, 6)
dev.off()

######### Lomb-Scargle periodogram oscillation analysis ###########

# Detrended HES5 data
Processed_HES5 <- read_excel("HES5 oscillation analysis output/ddhes5tt len7_5 fdr5/ProcessedData.xlsx", sheet = "RawDetrendedRAW", col_names = FALSE)
cell_names <- colnames(ddhes5tt[-1])
colnames(Processed_HES5) <- cell_names
Processed_HES5 <- as.data.frame(Processed_HES5)

pdf("lsp_hes5_detrended.pdf") 
for (i in 1:(length(Processed_HES5))){
  lsp(Processed_HES5[,i])
}
dev.off()

# Detrended NGN2 data
Processed_NGN2 <- read_excel("NGN2 oscillation analysis output /TracesNGN2 15LS vbrun all/ProcessedData.xlsx", sheet = "RawDetrendedRAW", col_names = FALSE)
cell_names <- colnames(ddngn2tt[-1])
colnames(Processed_NGN2) <- cell_names
Processed_NGN2 <- as.data.frame(Processed_NGN2)

pdf("lsp_ngn2_detrended.pdf") 
for (i in 1:(length(Processed_NGN2))){
  lsp(Processed_NGN2[,i])
}
dev.off()

############# Gaussian processes oscillation analysis ##############

# HES5 
osc_output_hes <- read_excel("HES5 oscillation analysis output/ddhes5tt len7_5 fdr5/SummaryFile.xls", sheet = "Sheet2", col_names = TRUE)

# Percentage of oscillatory and non-oscillatory HES5 expression
sum(osc_output_hes$FOD %in% 0 ) / nrow(osc_output_hes)
sum(osc_output_hes$FOD %in% 1 ) / nrow(osc_output_hes)

# Mean period of oscillators
tapply(osc_output_hes$`Period(h)`, osc_output_hes$FOD, mean)
tapply(osc_output_hes$`Period(h)`, osc_output_hes$FOD, sd)

# Create dataframe with cell number, osc or not, cluster number
osc_clust_hes <- data.frame(cells = colnames(hes[-1]), FOD = osc_output_hes$FOD)

cells_in_clust <- names(clusts)
osc_clust_hes <- osc_clust_hes[osc_clust_hes$cells %in% cells_in_clust, ]
osc_clust_hes$cluster <- clusts

pdf("osc_vs_nonosc.pdf")
proportions_hes <- osc_clust_hes %>%
  group_by(cluster, FOD) %>%
  summarise(count = n()) %>%
  group_by(cluster) %>%
  mutate(proportion = count / sum(count))

ggplot(proportions_hes, aes(x = factor(cluster), y = proportion, fill = factor(FOD))) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Proportion of Oscillators vs Non-Oscillators by Cluster (HES5)",
       x = "Cluster",
       y = "Proportion") +
  scale_fill_manual(values = c("1" = "lightblue", "0" = "darkblue"), name = "Oscillator", labels = c("Non-oscillator", "Oscillator")) +
  theme_minimal()

# NGN2
osc_output_ngn <- read_excel("NGN2 oscillation analysis output /TracesNGN2 15LS vbrun all/SummaryFile.xls", sheet = "Sheet2", col_names = TRUE)

# Percentage of oscillatory and non-oscillatory NGN2 expression
sum(osc_output_ngn$FOD %in% 0 ) / nrow(osc_output_ngn)
sum(osc_output_ngn$FOD %in% 1 ) / nrow(osc_output_ngn)

# Mean period of oscillators
tapply(osc_output_ngn$`Period(h)`, osc_output_ngn$FOD, mean)
tapply(osc_output_ngn$`Period(h)`, osc_output_ngn$FOD, sd)

# Create dataframe with cell number, osc or not, cluster number
osc_clust_ngn <- data.frame(cells = colnames(ngn[-1]), FOD = osc_output_ngn$FOD)

osc_clust_ngn <- osc_clust_ngn[osc_clust_ngn$cells %in% cells_in_clust, ]
osc_clust_ngn$cluster <- clusts

proportions_ngn <- osc_clust_ngn %>%
  group_by(cluster, FOD) %>%
  summarise(count = n()) %>%
  group_by(cluster) %>%
  mutate(proportion = count / sum(count))

ggplot(proportions_ngn, aes(x = factor(cluster), y = proportion, fill = factor(FOD))) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Proportion of Oscillators vs Non-Oscillators by Cluster (NGN2)",
       x = "Cluster",
       y = "Proportion") +
  scale_fill_manual(values = c("1" = "lightblue", "0" = "darkblue"), name = "Oscillator", labels = c("Non-oscillator", "Oscillator")) +
  theme_minimal()
dev.off()

# Comparing HES5 and NGN2 oscillations in cells
osc_both <- osc_clust_hes
osc_both$FOD_ngn <- osc_clust_ngn$FOD

osc_both[(osc_both$FOD == 1 & osc_both$FOD_ngn == 1),]

